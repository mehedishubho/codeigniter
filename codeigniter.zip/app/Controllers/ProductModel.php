<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class ProductModel extends BaseController
{
    public function index()
    {
        //
    }
}
